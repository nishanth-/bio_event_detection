BLLIP Parser contributors
=========================

Creators
^^^^^^^^

- `Eugene Charniak <http://cs.brown.edu/~ec/>`__ (parser)
- `Mark Johnson <http://web.science.mq.edu.au/~mjohnson/>`__ (reranker)

Maintainer
^^^^^^^^^^

- `David McClosky <https://github.com/dmcc>`__

Contributors
^^^^^^^^^^^^

- `Do Kook Choe <https://cs.brown.edu/people/dc65/home.html>`__
- `Patrick Claus <http://www.h-its.org/en/research/nlp/>`__
- `Shay Cohen <http://homepages.inf.ed.ac.uk/scohen/>`__
- `Micha Elsner <http://www.ling.ohio-state.edu/~melsner/>`__
- `Matthew Gerber <http://ptl.sys.virginia.edu/ptl/members/matthew-gerber>`__
- `William P. Headden III <https://github.com/headdenw>`__
- `Kristy Hollingshead <http://www.ihmc.us/groups/khollingshead/>`__
- `Matthew Lease <https://www.ischool.utexas.edu/~ml/>`__
- `Shashi Narayan <http://homepages.inf.ed.ac.uk/snaraya2/>`__
- `Vlad Niculae <https://github.com/vene>`__
- `Ben Swanson <https://github.com/chonger>`__
- Jenine Turner-Trauring
- `Jim White <https://github.com/jimwhite>`__
- `Didzis Gosko <https://github.com/didzis>`__

(and many others with helpful bug reports and questions!)

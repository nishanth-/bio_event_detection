#!/bin/bash
vncserver $DISPLAY -geometry 1280x800 -depth 24